package com.balimidi.config;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author balimiv
 *
 */
@RestController
public class ConfigController {

	@Autowired
	private ConfigService service;

	@GetMapping("/config/{id}")
	public List<String> getAttributes(@PathVariable final String id) {
		return service.getAttributes(id);
	}
}
