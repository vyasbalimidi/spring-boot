package com.balimidi.config;

import java.io.IOException;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Service;

/**
 * @author balimiv
 *
 */
@Service
public class ConfigService {
	private static final String	RES			= "transfer-attributes.properties";				//$NON-NLS-1$
	private static final Logger	LOGGER		= LoggerFactory.getLogger(ConfigService.class);
	private Properties			properties	= new Properties();

	@PostConstruct
	public void init() {
		try {
			final ClassPathResource resource = new ClassPathResource(RES);
			properties.load(resource.getInputStream());
		} catch (IOException exp) {
			final String msg = "Couldnt read the file ''{0}''. Attributes in PLMXML response will be less"; //$NON-NLS-1$
			LOGGER.error(MessageFormat.format(msg, RES));
		}
	}

	public List<String> getAttributes(final String key) {
		final List<String> attributes = new ArrayList<>();
		final String property = properties.getProperty(key);

		if (property != null) {
			for (final String attribute : property.split(",")) { //$NON-NLS-1$
				attributes.add(attribute.trim());
			}
		}

		return attributes;
	}
}
