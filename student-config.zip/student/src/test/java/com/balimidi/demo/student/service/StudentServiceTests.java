package com.balimidi.demo.student.service;

import static org.junit.Assert.assertEquals;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.junit.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.class)
public class StudentServiceTests {
	@InjectMocks
	StudentService service;

	@Test
	public void data() {
		final int max = service.findMaximum(12, 3, 54, 47, 23, 120, -65);
		assertEquals(120, max);
	}
}
