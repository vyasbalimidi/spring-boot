package com.balimidi.demo.student.controller;

import java.time.Instant;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.balimidi.demo.student.exception.ErrorDetails;

@ControllerAdvice
@RestController
public class ExceptionController extends ResponseEntityExceptionHandler {

	@Override
	protected ResponseEntity<Object> handleMethodArgumentNotValid(MethodArgumentNotValidException ex, HttpHeaders headers, HttpStatus status, WebRequest request) {
		final Instant now = Instant.now();
		final String message = "Validation Failed"; //$NON-NLS-1$
		final ErrorDetails errorDetails = new ErrorDetails(now, message);
		addDetails(ex, errorDetails);

		return new ResponseEntity<>(errorDetails, HttpStatus.BAD_REQUEST);
	}

	private void addDetails(final MethodArgumentNotValidException exp, final ErrorDetails errorDetails) {
		final BindingResult result = exp.getBindingResult();

		for (final ObjectError error : result.getAllErrors()) {
			errorDetails.addDetail(error.getDefaultMessage());
		}
	}
}
