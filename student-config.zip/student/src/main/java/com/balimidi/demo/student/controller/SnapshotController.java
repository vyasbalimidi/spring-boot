package com.balimidi.demo.student.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.balimidi.demo.student.model.Node;
import com.balimidi.demo.student.service.SnapshotService;
import com.balimidi.demo.student.util.NodeFinder;

/**
 * @author balimiv
 *
 */
@RestController
public class SnapshotController {

	@Autowired
	private SnapshotService service;

	@GetMapping("/snapshot/{id}")
	public ResponseEntity<Node> find(@PathVariable final String id) {
		final Node node = service.parseXML(id);
		return node != null ? ResponseEntity.ok(node) : ResponseEntity.notFound().build();
	}

	@GetMapping("/snapshot/{id}/{uuid}")
	public ResponseEntity<Node> find(@PathVariable final String id, @PathVariable final String uuid) {
		final Node node = service.parseXML(id);
		final NodeFinder finder = new NodeFinder(uuid);
		final Node search = finder.search(node);

		return search != null ? ResponseEntity.ok(search) : ResponseEntity.notFound().build();
	}

	@GetMapping("/snapshot/clear/{id}")
	public String clearCache(@PathVariable final String id) {
		return service.evictCache(id);
	}

	@GetMapping("/snapshot/clear-all")
	public String clearEntireCache() {
		return service.evictCacheAllEntries();
	}
}
