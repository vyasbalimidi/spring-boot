package com.balimidi.demo.student.domain;

import javax.persistence.Entity;
import javax.persistence.Id;

/**
 * @author balimiv
 *
 */
@Entity
public final class Department {
	@Id
	public long id;

	public String name;
	public String shortName;
	public String hod;

	public long numberOfStudents;

	public Department() {
		// Default
	}

	public Department(long id, String name, String shortName, String hod, long numberOfStudents) {
		this.id = id;
		this.name = name;
		this.shortName = shortName;
		this.hod = hod;
		this.numberOfStudents = numberOfStudents;
	}
}
