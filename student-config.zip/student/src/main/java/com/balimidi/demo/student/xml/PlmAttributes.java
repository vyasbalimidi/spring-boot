package com.balimidi.demo.student.xml;

/**
 * @author balimiv
 *
 */
@SuppressWarnings("nls")
public interface PlmAttributes {
	String	partRef			= "partRef";
	String	rootRefs		= "rootRefs";
	String	instanceRefs	= "instanceRefs";
	String	id				= "id";
	String	title			= "title";
	String	value			= "value";
}
