package com.balimidi.demo.student.util;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.client.RestTemplate;
import org.xml.sax.Attributes;
import org.xml.sax.helpers.DefaultHandler;

import com.balimidi.demo.student.model.Node;
import com.balimidi.demo.student.xml.PlmXml;

/**
 * @author balimiv
 *
 */
public final class XmlHandler extends DefaultHandler {
	private static final Logger				LOGGER	= LoggerFactory.getLogger(XmlHandler.class);

	private final Map<String, List<String>>	transferAttributes;
	private boolean							transferAttributesFailed;

	private final Map<String, Node>			instances;
	private final Map<String, Node>			parts;

	private Node							root;
	private Node							node;

	public XmlHandler() {
		transferAttributes = new HashMap<>();
		instances = new HashMap<>();
		parts = new HashMap<>();
	}

	@Override
	public void startElement(final String uri, final String lName, final String qName, final Attributes attributes) {
		switch (qName) {
		case PlmXml.InstanceGraph:
			root = new Node();

			root.xmlID = attributes.getValue(PlmXml.id);
			root.xmlRef = attributes.getValue(PlmXml.rootRefs);
			break;

		case PlmXml.Instance:
			node = new Node();

			node.xmlID = attributes.getValue(PlmXml.id);
			node.xmlRef = attributes.getValue(PlmXml.partRef);
			instances.put(node.xmlID, node);
			break;

		case PlmXml.Part:
			node = new Node();

			node.xmlID = attributes.getValue(PlmXml.id);
			node.xmlRef = attributes.getValue(PlmXml.instanceRefs);
			parts.put(node.xmlID, node);
			break;

		case PlmXml.UserValue:
			final String title = attributes.getValue(PlmXml.title);
			final String value = attributes.getValue(PlmXml.value);

			node.data.put(title, value);

			if (PlmXml.PartNumber.equals(title)) {
				node.name = value;
			} else if (PlmXml.Class.equals(title) && !transferAttributes.containsKey(value) && !transferAttributesFailed) {
				fillConfigurations(value);
			}
			break;

		default:
			break;
		}
	}

	@Override
	public void endElement(final String uri, final String localName, final String qName) {
		// All values are present as attributes
	}

	@Override
	public void characters(final char ch[], final int start, final int length) {
		// All values are present as attributes
	}

	private void fillConfigurations(final String className) {
		List<String> attributes = null;

		try {
			final String url = PlmXml.getTransferAttributesURL(className);
			final RestTemplate restTemplate = new RestTemplate();
			final List<?> result = restTemplate.getForObject(url, List.class);

			if (result != null && !result.isEmpty()) {
				attributes = new ArrayList<>();

				for (final Object object : result) {
					attributes.add((String) object);
				}
			}
		} catch (Exception exp) {
			transferAttributesFailed = true;
			LOGGER.error("Switch on Config server"); //$NON-NLS-1$
		}

		transferAttributes.put(className, attributes);
	}

	public Node build() {
		return root != null ? attachParts(root) : null;
	}

	private Node attachParts(final Node node) {
		final List<String> instanceIDs = StringUtil.split(node.xmlRef, StringUtil.SPACE);

		for (final String instanceID : instanceIDs) {
			final Node instance = instances.get(instanceID);
			final Node part = parts.get(instance.xmlRef);

			node.children.add(part);
			attachRequestedAttributes(part);
			attachParts(part);
		}

		return node;
	}

	private void attachRequestedAttributes(final Node node) {
		final String className = node.data.get(PlmXml.Class);
		final List<String> attributes = transferAttributes.get(className);

		if (attributes != null) {
			node.data.entrySet().removeIf(e -> !attributes.contains(e.getKey()));
		} else {
			node.data.clear();
		}
	}
}
