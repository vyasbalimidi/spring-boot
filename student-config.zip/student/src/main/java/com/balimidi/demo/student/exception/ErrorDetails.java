package com.balimidi.demo.student.exception;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

public class ErrorDetails {
	private final Instant		timestamp;
	private final String		message;
	private final List<String>	details;

	public ErrorDetails(Instant timestamp, String message) {
		this.timestamp = timestamp;
		this.message = message;
		this.details = new ArrayList<>();
	}

	public Instant getTimestamp() {
		return timestamp;
	}

	public String getMessage() {
		return message;
	}

	public void addDetail(final String detail) {
		details.add(detail);
	}
	
	public List<String> getDetails() {
		return details;
	}
}
