package com.balimidi.demo.student.util;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.UUID;

/**
 * @author balimiv
 *
 */
@SuppressWarnings("nls")
public interface StringUtil {
	String SPACE = " ";

	static List<String> split(final String data, final String delimitor) {
		return data != null ? Arrays.asList(data.split(delimitor)) : Collections.emptyList();
	}

	static String uuid() {
		return UUID.randomUUID().toString().replace("-", "");
	}
}
