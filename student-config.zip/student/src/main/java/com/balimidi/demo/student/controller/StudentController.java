package com.balimidi.demo.student.controller;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.balimidi.demo.student.domain.Course;
import com.balimidi.demo.student.domain.Department;
import com.balimidi.demo.student.domain.Student;
import com.balimidi.demo.student.service.StudentService;

/**
 * @author balimiv
 *
 */
@RestController
@RequestMapping("/api")
public final class StudentController {

	@Autowired
	private StudentService service;

	@GetMapping("/departments")
	public List<Department> getDepartments() {
		return service.fetchDepartments();
	}

	@GetMapping("/departments/{id}")
	public ResponseEntity<Department> getDepartmentByID(@PathVariable final long id) {
		final Optional<Department> department = service.fetchDepartment(id);
		return department.isPresent() ? ResponseEntity.ok(department.get()) : ResponseEntity.notFound().build();
	}

	@GetMapping("/courses")
	public List<Course> getCourses() {
		return service.fetchCourses();
	}

	@GetMapping("/courses/{id}")
	public ResponseEntity<Course> getCourseByID(@PathVariable final long id) {
		final Optional<Course> course = service.fetchCourse(id);
		return course.isPresent() ? ResponseEntity.ok(course.get()) : ResponseEntity.notFound().build();
	}

	@GetMapping("/students")
	public List<Student> getStudents(@PageableDefault(page = 0, size = Integer.MAX_VALUE) Pageable pageable) {
		return service.fetchStudents(pageable);
	}

	@GetMapping("/students/{id}")
	public ResponseEntity<Student> getStudentByID(@PathVariable final long id) {
		final Optional<Student> student = service.fetchStudent(id);
		return student.isPresent() ? ResponseEntity.ok(student.get()) : ResponseEntity.notFound().build();
	}

	@PostMapping("/students")
	public Student createStudent(@Valid @RequestBody final Student student) {
		return service.createStudent(student);
	}
}
