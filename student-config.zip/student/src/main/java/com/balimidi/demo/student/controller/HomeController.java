package com.balimidi.demo.student.controller;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ResponseBody;

/**
 * @author balimiv
 *
 */
@Controller
public class HomeController {
	@Value("${env}")
	private String env;

	@GetMapping("/env")
	@ResponseBody
	public String environment() {
		return env;
	}

	@GetMapping("/home")
	public String homePage() {
		return "home"; //$NON-NLS-1$
	}

	@GetMapping("/add-student")
	public String addStudent() {
		return "addStudent"; //$NON-NLS-1$
	}
}
