package com.balimidi.demo.student.xml;

/**
 * @author balimiv
 *
 */
@SuppressWarnings("nls")
public interface PlmTags {
	String	InstanceGraph	= "InstanceGraph";
	String	Instance		= "Instance";
	String	Part			= "Part";
	String	UserValue		= "UserValue";
}
