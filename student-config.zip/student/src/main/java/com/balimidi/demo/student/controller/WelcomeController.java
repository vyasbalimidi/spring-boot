package com.balimidi.demo.student.controller;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ResponseBody;

/**
 * @author balimiv
 *
 */
@Controller
public class WelcomeController {
	@Value("${env}")
	private String env;

	@GetMapping("/env")
	@ResponseBody
	public String environment() {
		return env;
	}

	@GetMapping("/welcome")
	public String loginMessage() {
		return "welcome"; //$NON-NLS-1$
	}
}
