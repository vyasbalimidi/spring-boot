package com.balimidi.demo.student.xml;

/**
 * @author balimiv
 *
 */
@SuppressWarnings("nls")
public interface PlmKeys {
	String	Class		= "Class";
	String	PartNumber	= "PartNumber";
}
