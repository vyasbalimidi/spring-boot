package com.balimidi.demo.student.domain;

import java.time.LocalDate;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

/**
 * @author balimiv
 *
 */
@Entity
@SequenceGenerator(name = "seq", initialValue = 13)
public final class Student {
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seq")
	public long			id;

	@NotNull(message = "Field 'firstname' must not be null")
	@Size(min = 2, message = "Field 'firstname' must have a minimum of 2 characters")
	public String		firstname;

	@NotNull(message = "Field 'lastname' must not be null")
	@Size(min = 2, message = "Field 'lastname' must have a minimum of 2 characters")
	public String		lastname;

	@NotNull(message = "Field 'gender' must not be null")
	@Pattern(regexp = "male|female", flags = Pattern.Flag.CASE_INSENSITIVE, message = "Field 'gender' allowed value are 'Male' & 'Female'")
	public String		gender;

	public LocalDate	dob;

	public Student() {
		// Default
	}

	public Student(long id, String firstname, String lastname, String gender, LocalDate dob) {
		this.id = id;
		this.firstname = firstname;
		this.lastname = lastname;
		this.gender = gender;
		this.dob = dob;
	}
}
