package com.balimidi.demo.student.xml;

import java.text.MessageFormat;

/**
 * @author balimiv
 *
 */
@SuppressWarnings("nls")
public interface PlmXml extends PlmTags, PlmAttributes, PlmKeys {
	String	LOC	= "C:\\TEMP\\{0}.plmxml";
	String	URI	= "http://localhost:8090/config/";

	static String path(final String filename) {
		return MessageFormat.format(LOC, filename);
	}

	static String getTransferAttributesURL(final String className) {
		return URI + className;
	}
}
