package com.balimidi.demo.student.model;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.balimidi.demo.student.util.StringUtil;
import com.fasterxml.jackson.annotation.JsonIgnore;

/**
 * @author balimiv
 *
 */
public class Node {
	@JsonIgnore
	public String						xmlID;
	@JsonIgnore
	public String						xmlRef;

	public final String					id			= StringUtil.uuid();
	public final Map<String, String>	data		= new HashMap<>();
	public final List<Node>				children	= new ArrayList<>();

	public String						name;
}
