package com.balimidi.demo.student.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.balimidi.demo.student.domain.Department;

/**
 * @author balimiv
 *
 */
@Repository
public interface DepartmentRepository extends JpaRepository<Department, Long> {

}
