package com.balimidi.demo.student.service;

import java.io.File;
import java.text.MessageFormat;

import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.springframework.cache.annotation.CacheConfig;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import com.balimidi.demo.student.model.Node;
import com.balimidi.demo.student.util.XmlHandler;
import com.balimidi.demo.student.xml.PlmXml;

/**
 * @author balimiv
 *
 */
@Service
@CacheConfig(cacheNames = { SnapshotService.CACHE })
public class SnapshotService {
	public static final String CACHE = "snapshots"; //$NON-NLS-1$

	@Cacheable
	public Node parseXML(final String filename) {
		final File file = new File(PlmXml.path(filename));
		final XmlHandler handler = new XmlHandler();

		try {
			final SAXParser parser = SAXParserFactory.newInstance().newSAXParser();
			parser.parse(file, handler);
		} catch (Exception exp) {
			// All exceptions are dissolved
		}

		final Node build = handler.build();
		return build != null ? build.children.get(0) : null;
	}

	@CacheEvict(value = CACHE, allEntries = true)
	public String evictCacheAllEntries() {
		return "Removed all entries from the cache"; //$NON-NLS-1$
	}

	@CacheEvict(value = CACHE, key = "#filename")
	public String evictCache(final String filename) {
		return MessageFormat.format("Removed an entry with the key ''{0}''", filename); //$NON-NLS-1$
	}
}
