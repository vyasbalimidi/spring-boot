package com.balimidi.demo.student.util;

import com.balimidi.demo.student.model.Node;

/**
 * @author balimiv
 *
 */
public class NodeFinder {
	private final String	uuid;
	private Node			found;

	public NodeFinder(final String uuid) {
		this.uuid = uuid;
	}

	public Node search(final Node node) {
		if (uuid == null) {
			return node;
		}

		find(node);

		return found;
	}

	private void find(final Node node) {
		if (node.id.equals(uuid)) {
			found = node;
			return;
		}

		for (final Node child : node.children) {
			find(child);
		}

		return;
	}
}
