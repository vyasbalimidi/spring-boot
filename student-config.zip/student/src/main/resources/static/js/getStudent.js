$(document).ready(
		function() {
			$.ajax({
				url : "/api/students"
			}).then(
					function(data) {
						$.each(data, function(index, value) {
							console.log(value);
							$('#studentsList').append(
									'<tr>' + '<td>' + value.firstname + '</td>'
											+ '<td>' + value.lastname + '</td>'
											+ '<td>' + value.gender + '</td>'
											+ '<td>' + value.dob + '</td>'
											+ '</tr>');
						});
					});
		});