$(document).ready(
		function() {
			$.ajax({
				url : "/students"
			}).then(
					function(data) {
						$.each(data, function(index, value) {
							console.log(value);
							$('#students').append(
									'<tr>' + '<td>' + value.firstname + '</td>'
											+ '<td>' + value.lastname + '</td>'
											+ '<td>' + value.gender + '</td>'
											+ '<td>' + value.dob + '</td>'
											+ '</tr>');
						});
					});
		});