package com.balimidi.demo.student.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.balimidi.demo.student.model.Course;
import com.balimidi.demo.student.model.Department;
import com.balimidi.demo.student.model.Student;
import com.balimidi.demo.student.repository.CourseRepository;
import com.balimidi.demo.student.repository.DepartmentRepository;
import com.balimidi.demo.student.repository.StudentRepository;

/**
 * @author balimiv
 *
 */
@Service
public class StudentService {
	@Autowired
	private DepartmentRepository departmentRepo;

	@Autowired
	private CourseRepository courseRepo;

	@Autowired
	private StudentRepository studentRepo;

	public List<Department> fetchDepartments() {
		return departmentRepo.findAll();
	}

	public Optional<Department> fetchDepartment(final long id) {
		return departmentRepo.findById(id);
	}

	public List<Course> fetchCourses() {
		return courseRepo.findAll();
	}

	public Optional<Course> fetchCourse(final long id) {
		return courseRepo.findById(id);
	}

	public List<Student> fetchStudents(final Pageable pageable) {
		return studentRepo.findAll(pageable).getContent();
	}

	public Optional<Student> fetchStudent(long id) {
		return studentRepo.findById(id);
	}

	// To demo how MockIto JUnit testing works
	public int findMaximum(int... numbers) {
		int maximum = Integer.MIN_VALUE;

		for (int num : numbers) {
			if (num > maximum) {
				maximum = num;
			}
		}

		return maximum;
	}
}
