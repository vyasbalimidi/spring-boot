package com.balimidi.demo.student.model;

import javax.persistence.Entity;
import javax.persistence.Id;

/**
 * @author balimiv
 *
 */
@Entity
public final class Course {
	@Id
	public long id;

	public String name;
	public String professor;

	public int numberOfHours;
	public int credits;

	public Course() {
		// Default
	}

	public Course(long id, String name, String professor, int numberOfHours, int credits) {
		this.id = id;
		this.name = name;
		this.professor = professor;
		this.numberOfHours = numberOfHours;
		this.credits = credits;
	}
}
