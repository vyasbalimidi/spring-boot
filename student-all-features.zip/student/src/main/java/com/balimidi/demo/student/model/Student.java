package com.balimidi.demo.student.model;

import java.time.LocalDate;

import javax.persistence.Entity;
import javax.persistence.Id;

/**
 * @author balimiv
 *
 */
@Entity
public final class Student {
	@Id
	public long id;

	public String firstname;
	public String lastname;
	public String gender;

	public LocalDate dob;

	public Student() {
		// Default
	}

	public Student(long id, String firstname, String lastname, String gender, LocalDate dob) {
		this.id = id;
		this.firstname = firstname;
		this.lastname = lastname;
		this.gender = gender;
		this.dob = dob;
	}
}
