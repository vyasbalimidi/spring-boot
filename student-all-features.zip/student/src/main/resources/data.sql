/* ------------------ */
insert into department 
values(1, 'Dharma', 'Computer Science Engineering', 0, 'CSE');

insert into department 
values(2, 'Bheema', 'Electronics Communications Engineering', 0, 'ECE');

insert into department 
values(3, 'Arjuna', 'Electronics & Electrical Engineering', 0, 'EEE');

insert into department 
values(4, 'Nakula', 'Mechanical Engineering', 0, 'ME');

insert into department 
values(5, 'Sahadeva', 'Civil Engineering', 0, 'CE');

/* ------------------ */
insert into course
values(1, 3, 'Data Structures', 100, 'Rama');

insert into course
values(2, 4, 'Embeddded Systems', 80, 'Sita');

insert into course
values(3, 1, 'Digital Electronics', 120, 'Ravana');

insert into course
values(4, 2, 'Physics', 120, 'Lakshmana');

insert into course
values(5, 2, 'Chemistry', 75, 'Anjaneya');

insert into course
values(6, 2, 'Mathematics', 150, 'Vaali');

/* ------------------ */
insert into student
values(1, '1988-6-10', 'Ashwin', 'Male', 'Kumar');

insert into student
values(2, '1987-9-30', 'Gangaraj', 'Male', 'Ramanna');

insert into student
values(3, '1990-7-10', 'Akhilesh', 'Male', 'Sreelayam');

insert into student
values(4, '1989-8-19', 'Vyas', 'Male', 'Balimidi');

insert into student
values(5, '1992-10-30', 'Sneha', 'Female', 'Vagga');

insert into student
values(6, '1991-12-31', 'Swathi', 'Female', 'Balimidi');

insert into student
values(7, '1991-12-31', 'Rahul', 'Male', 'Joshi');

insert into student
values(8, '1980-01-01', 'Dharma', 'Male', 'Pandava');

insert into student
values(9, '1980-01-01', 'Bheema', 'Male', 'Pandava');

insert into student
values(10, '1980-01-01', 'Arjuna', 'Male', 'Pandava');

insert into student
values(11, '1980-01-01', 'Nakula', 'Male', 'Pandava');

insert into student
values(12, '1980-01-01', 'Sahadeva', 'Male', 'Pandava');
