$(document).ready(function() {
	$.ajax({
		url : "/students"
	}).then(function(data) {
		$.each(data, function(index, value) {
			alert(index + ": " + value.firstname);
		});
	});
});